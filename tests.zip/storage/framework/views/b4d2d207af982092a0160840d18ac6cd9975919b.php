<html>

<head>
    <link rel="icon" href="<?php echo e(asset('logo')); ?>/dishub.png" width="50px">
</head>

<body onload="window.print()">
    <div class="form-group">
        <h2 class="page-header" align="center">
            <h2 align="center"><u>REKAPITULASI PENERIMAAN BIAYA IZIN INSIDENTIL</u></h2><br>
            <small class="pull-right"></small>
        </h2>
        <table border="1" cellspacing="1" cellpadding="1" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No. Kend / No. Uji</th>
                    <th>Merk / Tahun / Habis Uji / Terbit</th>
                    <th>Maksud / Tujuan Perjalanan</th>
                    <th>Tanggal Perjalanan</th>
                    <th>Retribusi</th>
                </tr>
            </thead>

            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $insidentil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($no++); ?></td>
                    <td><?php echo e($data->no_kend); ?> / <?php echo e($data->no_uji); ?></td>
                    <td><?php echo e($data->merk); ?> / <?php echo e($data->tahun); ?> <br><?php echo e(Carbon\Carbon::parse($data->habis_uji)->isoFormat('D MMMM Y')); ?> <br> <?php echo e(Carbon\Carbon::parse($data->terbit)->isoFormat('D MMMM Y')); ?></td>
                    <td><?php echo e($data->maksud); ?> <br> <?php echo e($data->tujuan); ?></td>
                    <td><?php echo e(Carbon\Carbon::parse($data->tgl_awal_perjalanan)->isoFormat('D MMMM Y')); ?> s/d <?php echo e(Carbon\Carbon::parse($data->tgl_akhir_perjalanan)->isoFormat('D MMMM Y')); ?></td>
                    <td>Rp. <?php echo number_format($data->retri,0,',','.'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="5" rowspan="2" align="right"><b>Jumlah Kendaraan : <?php echo e($no-1); ?> Unit/Kendaraan</b></td>
                    <td>Rp. <?php echo number_format($insidentil->sum('retri'),0,',','.'); ?></td>
                </tr>
                <tr>
                    <td colspan="5" align="center"><b>Rp. <?php echo number_format($insidentil->sum('retri'),0,',','.'); ?></b></td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_insidentil/cetakpenerimaan.blade.php ENDPATH**/ ?>