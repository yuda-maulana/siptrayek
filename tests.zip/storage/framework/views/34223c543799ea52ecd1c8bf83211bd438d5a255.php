<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekomendasi | Laporan Penerimaan Biaya Retribusi</title>
    <link rel="icon" href="<?php echo e(asset('logo')); ?>/dishub.png" width="50px">
</head>

<body onload="window.print()">
    <div class="form-group">
        <h2 class="page-header" align="center">
            <h2 align="center">REKAPITULASI PENERIMAAN BIAYA IZIN KHUSUS</h2><br>
            <small class="pull-right"></small>
        </h2>
        <table border="1" cellspacing="1" cellpadding="1" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No. Uji <br> No. Kend</th>
                    <th>Pemilik <br> Alamat</th>
                    <th>Jenis, Merk, Tahun Kendaraan</th>
                    <th>Daya Angkut</th>
                    <th>Retribusi</th>
                    <th>Periode <br> Adm.</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $khusus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($no++); ?></td>
                    <td><?php echo e($data->no_uji); ?> <br> <?php echo e($data->no_kend); ?></td>
                    <td><?php echo e($data->pemilik); ?> <br><?php echo e($data->alamat); ?></td>
                    <td><?php echo e($data->jenis_kendaraan); ?> <br><?php echo e($data->merk); ?> <br><?php echo e($data->tahun); ?></td>
                    <td><?php echo e($data->dy_akt); ?></td>
                    <td>Rp. <?php echo number_format($data->retri,0,',','.'); ?></td>
                    <td>Rp. <?php echo number_format($data->periode,0,',','.'); ?> <br>Rp. <?php echo number_format($data->administrasi,0,',','.'); ?></td>
                </tr>
                <tr>
                    <td colspan="5" rowspan="2" align="right"><b>Total</b></td>
                    <td>Rp. <?php echo number_format($data->retri,0,',','.'); ?></td>
                    <td>Rp. <?php echo number_format($data->periode,0,',','.'); ?> <br>Rp. <?php echo number_format($data->administrasi,0,',','.'); ?></td>
                </tr>
                <tr>
                    <td colspan="4" align="center"><b>Rp. <?php echo number_format($data->retri+$data->periode+$data->administrasi,0,',','.'); ?></b></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="5" rowspan="2" align="right"><b>Jumlah Kendaraan : <?php echo e($no-1); ?> Unit/Kendaraan</b></td>
                    <td>Rp. <?php echo number_format($khusus->sum('retri'),0,',','.'); ?></td>
                    <td>Rp. <?php echo number_format($khusus->sum('periode'),0,',','.'); ?> <br>Rp. <?php echo number_format($khusus->sum('administrasi'),0,',','.'); ?></td>
                </tr>
                <tr>
                    <td colspan="2" align="center"><b>Rp. <?php echo number_format($khusus->sum('retri')+$khusus->sum('periode')+$khusus->sum('administrasi'),0,',','.'); ?></b></td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_khusus/cetakpenerimaan.blade.php ENDPATH**/ ?>