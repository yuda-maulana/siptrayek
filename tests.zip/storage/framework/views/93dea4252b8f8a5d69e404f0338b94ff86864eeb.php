
<?php $__env->startSection('title', 'Target Retribusi'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('pesan')): ?>
<div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-check"></i> Berhasil!</h4>
    <?php echo e(session('pesan')); ?>

</div>
<?php endif; ?>
<section class="content">
    <div class="row">
        <div class="col-xs-15">
            <div class="box">
                <div class="box-header">
                    <a href="add" class="btn btn-success btn-sm">Tambah Data</a>
                    <!-- </div>
                <div class="box-header"> -->
                    <div class="box-tools">
                        <form action="/v_target/target" method="get">
                            <div class="input-group input-group-sm" style="width: 220px;">
                                <input type="text" name="search" class="form-control pull-left" placeholder="Cari berdasarkan nama rek, kode rek, dan tahun">
                                <div class="input-group-btn">
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tr>
                            <th>No</th>
                            <th>Kode Rek</th>
                            <th>Nama Rek</th>
                            <th>Target Awal</th>
                            <th>Target Perbulan</th>
                            <th>Target Akhir</th>
                            <th>Tahun</th>
                            <th>Aksi</th>
                        </tr>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $target; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($data->kode_rek); ?></td>
                            <td><?php echo e($data->nama_rek); ?></td>
                            <td>Rp. <?php echo number_format($data->target1,0,',','.'); ?></td>
                            <td>Rp. <?php echo number_format($data->target2,0,',','.'); ?></td>
                            <td>Rp. <?php echo number_format($data->target3,0,',','.'); ?></td>
                            <td><?php echo e($data->tahun); ?></td>
                            <td>
                                <!-- <a href="/v_target/detail/<?php echo e($data->id); ?>" class="btn btn-sm btn-info">Detail</a> -->
                                <a href="/v_target/edit/<?php echo e($data->id); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete<?php echo e($data->id); ?>">
                                    Hapus
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <div class="box-footer clearfix">
                    <div class="d-flex justify-content-center">
                        <p>Halaman saat ini : <b><?php echo e($target->currentPage()); ?></b></p>
                        <p>Jumlah Data : <b><?php echo e($target->total()); ?></b></p>
                        <p>Data perhalaman : <b><?php echo e($target->perPage()); ?></b></p>
                        <?php echo e($target->links()); ?>

                    </div>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php $__currentLoopData = $target; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal modal-danger fade" id="delete<?php echo e($data->id); ?>">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo e($data->kode_rek); ?></h4>
            </div>
            <div class="modal-body">
                <p>Apakah anda yakin ingin menghapus data ini?</p>
            </div>
            <div class="modal-footer">
                <a href="" class="btn btn-outline pull-left" data-dismiss="modal">Tidak</a>
                <a href="/v_target/delete/<?php echo e($data->id); ?>" class="btn btn-outline">Ya</a>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_target/target.blade.php ENDPATH**/ ?>