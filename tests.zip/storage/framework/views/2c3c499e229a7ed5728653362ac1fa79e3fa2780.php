<ul class="sidebar-menu" data-widget="tree">
    <li class="header">MAIN NAVIGATION</li>
    <li class="<?php echo e(request()->is('/') ? 'active' : ''); ?>"><a href="/"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
    <li class="treeview active menu-open">
        <a href="#">
            <i class="fa fa-th-list"></i> <span>Izin Trayek</span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
            <li class="<?php echo e(request()->is('v_lintrayek/lintrayek') ? 'active' : ''); ?>"><a href="/v_lintrayek/lintrayek"><i class="fa fa-road"></i> Data Lintasan Trayek</a></li>
            <li class="<?php echo e(request()->is('v_trayek/trayek') ? 'active' : ''); ?>"><a href="/v_trayek/trayek"><i class="fa fa-map"></i> Data Izin Trayek</a></li>
        </ul>
    </li>
    <!-- <li class="<?php echo e(request()->is('v_insidentil/insidentil') ? 'inactive' : ''); ?>"><a href="/v_insidentil/insidentil"><i class="fa fa-road"></i> <span>Izin Trayek</span></a></li> -->
    <!-- <li class="<?php echo e(request()->is('v_insidentil/insidentil') ? 'inactive' : ''); ?>"><a href="/v_insidentil/insidentil"><i class="fa fa-money"></i> <span>Izin Usaha</span></a></li> -->
    <li class="<?php echo e(request()->is('v_insidentil/insidentil') ? 'active' : ''); ?>"><a href="/v_insidentil/insidentil"><i class="fa fa-book"></i> <span>Izin Insidentil</span></a></li>
    <!-- <li class="<?php echo e(request()->is('v_insidentil/insidentil') ? 'inactive' : ''); ?>"><a href="/v_insidentil/insidentil"><i class="fa fa-comments-o"></i> <span>Izin Prinsip</span></a></li> -->
    <!-- <li class="<?php echo e(request()->is('v_insidentil/insidentil') ? 'inactive' : ''); ?>"><a href="/v_insidentil/insidentil"><i class="fa fa-bus"></i> <span>Izin Khusus</span></a></li>
    <li class="<?php echo e(request()->is('v_insidentil/insidentil') ? 'inactive' : ''); ?>"><a href="/v_insidentil/insidentil"><i class="fa fa-car"></i> <span>Izin Operasi Taksi</span></a></li> -->
    <li class="<?php echo e(request()->is('v_rekomendasi/rekomendasi') ? 'active' : ''); ?>"><a href="/v_rekomendasi/rekomendasi"><i class="fa fa-lightbulb-o"></i> <span>Rekomendasi</span></a></li>
    <li class="<?php echo e(request()->is('v_profile/profile') ? 'active' : ''); ?>"><a href="/v_profile/profile"><i class="fa fa-user"></i> <span>Profile</span></a></li>
    <?php if(auth()->user()->level==1): ?>
    <li class="<?php echo e(request()->is('v_user/user') ? 'active' : ''); ?>"><a href="/v_user/user"><i class="fa fa-users"></i> <span>User</span></a></li>
    <?php endif; ?>
</ul><?php /**PATH C:\xampp\htdocs\project\dishub\resources\views/layout/nav.blade.php ENDPATH**/ ?>