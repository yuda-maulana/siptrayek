
<?php $__env->startSection('title', 'Form Realisasi Lintasan Tertentu'); ?>
<?php $__env->startSection('content'); ?>

<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box box-primary">
                <!-- <form role="form"> -->
                <div class="box-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="lin">Trayek</label>
                                <select class="form-control" name="lin" id="lin">
                                    <option disabled value>Pilih Lintasan</option>
                                    <?php $__currentLoopData = $lintrayek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->kode); ?>:<?php echo e($item->lintasan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="" onclick="this.href='/v_trayek/cetaklintertentu/'+ document.getElementById('lin').value" target="_blank"><button class="btn btn-success">Cetak Laporan</button></a>
                    <a href="trayek" class="btn btn-danger">Batal</a>
                </div>
                <!-- </form> -->
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_trayek/formlintertentu.blade.php ENDPATH**/ ?>