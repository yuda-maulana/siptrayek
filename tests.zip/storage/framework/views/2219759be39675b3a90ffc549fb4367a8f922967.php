<html>

<body onload="window.print()">
    <div class="form-group">
        <h2 class="page-header" align="center">
            <i class="fa fa-globe"></i>LAPORAN KEGIATAN HARIAN PELAYANAN REKOMENDASI<br>
            <small class="pull-right">Tanggal : <?php echo e(date('d-M-Y')); ?></small>
        </h2>
        <table border="1" cellspacing="1" cellpadding="1" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal <br> No. Bend</th>
                    <th>Nama <br> Perusahaan <br> Alamat</th>
                    <th>Jenis / Sifat Pelayanan <br>Trayek Dimohon</th>
                    <th>Jenis / Jumlah Kendaraan</th>
                    <th>Tgl. Terbit / NIK / Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($no++); ?></td>
                    <td><?php echo e(Carbon\Carbon::parse($data->tanggal)->isoFormat('D MMMM Y')); ?> <br> <?php echo e($data->no_bend); ?></td>
                    <td><?php echo e($data->pemilik); ?> <br> <?php echo e($data->perusahaan); ?> <br><?php echo e($data->alamat); ?></td>
                    <td><?php echo e($data->layanan); ?> <br><?php echo e($data->sifat); ?> <br><?php echo e($data->trayek); ?></td>
                    <td><?php echo e($data->jenis); ?> <br> <?php echo e($data->jumlah); ?></td>
                    <td><?php echo e(Carbon\Carbon::parse($data->terbit)->isoFormat('D MMMM Y')); ?> <br><?php echo e($data->urut); ?> <br><?php echo e($data->catatan); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_rekomendasi/lapharian.blade.php ENDPATH**/ ?>