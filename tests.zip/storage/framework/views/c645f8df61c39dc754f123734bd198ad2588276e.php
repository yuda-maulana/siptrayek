
<?php $__env->startSection('title', 'Detail Rekomendasi'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <a href="/v_rekomendasi/edit/<?php echo e($rekomendasi->id); ?>" class="btn btn-sm btn-warning pull-right">Edit Data</a>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Tanggal</th>
                                <td><?php echo e(Carbon\Carbon::parse($rekomendasi->tgl_rekom)->format('d/m/Y')); ?></td>
                            </tr>
                            <tr>
                                <th>No. Bend</th>
                                <td><?php echo e($rekomendasi->no_bend); ?></td>
                            </tr>
                            <tr>
                                <th>Nama Pemilik</th>
                                <td><?php echo e($rekomendasi->pemilik); ?></td>
                            </tr>
                            <tr>
                                <th>Perusahaan</th>
                                <td><?php echo e($rekomendasi->perusahaan); ?></td>
                            </tr>
                            <tr>
                                <th>Alamat</th>
                                <td><?php echo e($rekomendasi->alamat); ?></td>
                            </tr>
                            <tr>
                                <th>Jenis / Sifat Pelayanan</th>
                                <td><?php echo e($rekomendasi->jns_pelayanan); ?> / <?php echo e($rekomendasi->sifat_pelayanan); ?></td>
                            </tr>
                            <tr>
                                <th>Jenis / Jumlah Kendaraan</th>
                                <td><?php echo e($rekomendasi->jns_kendaraan); ?> / <?php echo e($rekomendasi->jmlh_kendaraan); ?></td>
                            </tr>
                            <tr>
                                <th>Trayek Dimohon</th>
                                <td><?php echo e($rekomendasi->trayek_dimohon); ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal Terbit</th>
                                <td><?php echo e(Carbon\Carbon::parse($rekomendasi->tgl_terbit)->format('d/m/Y')); ?></td>
                            </tr>
                            <tr>
                                <th>Retribusi</th>
                                <td><?php echo e($rekomendasi->retribusi); ?></td>
                            </tr>
                            <tr>
                                <th>Leges</th>
                                <td><?php echo e($rekomendasi->leges); ?></td>
                            </tr>
                            <tr>
                                <th>Keterangan</th>
                                <td><?php echo e($rekomendasi->keterangan); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="box-footer">
                    <a href="../rekomendasi" class="btn btn-success btn-sm ">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\dishub\resources\views/v_rekomendasi/detail.blade.php ENDPATH**/ ?>