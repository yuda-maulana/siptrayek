
<?php $__env->startSection('title', 'Form Laporan Proses SK/KP Izin Trayek'); ?>
<?php $__env->startSection('content'); ?>

<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box box-primary">
                <!-- <form role="form"> -->
                <div class="box-body">
                    <div class="row">
                        <form id="myform" name="myform" action="" method="post">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>
                                        <input type="radio" name="group1" value="Tanggal" checked="checked">
                                        Pertanggal
                                    </label>
                                    <br>
                                    <label>
                                        <input type="radio" name="group1" value="Pertanggal">
                                        Tanggal Tertentu
                                    </label>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="tglawal"></label>
                                    <input type="date" name="tglawal" class="form-control" id="tglawal" value="<?php echo e(old('tglawal')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['tglawal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="tglakhir"></label>
                                    <input type="date" name="tglakhir" class="form-control" id="tglakhir" value="<?php echo e(old('tglakhir')); ?>" disabled="disabled">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['tglakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="" onclick="this.href='/v_trayek/cetaklaporan/'+ document.getElementById('tglawal').value + '/' + document.getElementById('tglakhir').value" target="_blank"><button class="btn btn-success">Cetak Laporan</button></a>
                    <a href="trayek" class="btn btn-danger">Batal</a>
                </div>
                <!-- </form> -->
            </div>
        </div>
    </div>
</section>
<script>
    var form = document.forms['myform'];
    form.group1[0].onfocus = function() {
        form.tglawal.disabled = false;
        form.tglakhir.disabled = true;
    }
    form.group1[1].onfocus = function() {
        form.tglawal.disabled = form.tglakhir.disabled = false;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_trayek/formkegiatan.blade.php ENDPATH**/ ?>