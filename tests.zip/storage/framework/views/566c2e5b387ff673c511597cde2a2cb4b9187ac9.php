
<?php $__env->startSection('title', 'Detail Lintasan Trayek'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-xs-15">
            <div class="box">
                <div class="box-header">
                    <a href="/v_lintrayek/edit/<?php echo e($lintrayek->id); ?>" class="btn btn-sm btn-warning">Edit Data</a>
                    <a href="/v_lintrayek/printlintrayek/<?php echo e($lintrayek->id); ?>" class="btn btn-sm btn-info pull-right">Cetak Data</a>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Kode Lintasan</th>
                                <td><?php echo e($lintrayek->kode); ?></td>
                            </tr>
                            <tr>
                                <th>Lintasan Trayek</th>
                                <td><?php echo e($lintrayek->lintasan); ?></td>
                            </tr>
                            <tr>
                                <th>Alokasi</th>
                                <td><?php echo e($lintrayek->alokasi); ?></td>
                            </tr>
                            <tr>
                                <th>Realisasi</th>
                                <td><?php echo e($lintrayek->realisasi); ?></td>
                            </tr>
                            <tr>
                                <th>Aktif</th>
                                <td><?php echo e($lintrayek->aktif); ?></td>
                            </tr>
                            <tr>
                                <th>Non Aktif</th>
                                <td><?php echo e($lintrayek->nonaktif); ?></td>
                            </tr>
                            <tr>
                                <th>Sisa Alokasi</th>
                                <td><?php echo e($lintrayek->alokasi-$lintrayek->realisasi); ?></td>
                            </tr>
                            <tr>
                                <th>Rute</th>
                                <td><?php echo e($lintrayek->rute); ?></td>
                            </tr>
                            <tr>
                                <th>Jenis</th>
                                <td><?php echo e($lintrayek->jenis); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="box-footer">

                    <a href="../lintrayek" class="btn btn-success btn-sm ">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_lintrayek/detail.blade.php ENDPATH**/ ?>