<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Izin Operasi Taksi | Laporan Penerimaan Biaya Operasi Taksi</title>
    <link rel="icon" href="<?php echo e(asset('logo')); ?>/dishub.png" width="50px">
</head>

<body onload="window.print()">
    <div class="form-group">
        <h2 class="page-header" align="center">
            <h2 align="center">REKAPITULASI PENERIMAAN BIAYA IZIN OPERASI TAKSI</h2><br>
            <small class="pull-right"></small>
        </h2>
        <table border="1" cellspacing="1" cellpadding="1" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No. Uji <br> No. Kend</th>
                    <th>Pemilik <br> Perusahaan <br> Alamat</th>
                    <th>Jenis, Merk, Tahun Kendaraan</th>
                    <th>Retribusi</th>
                    <th>Periode <br> Adm.</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $taksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($no++); ?></td>
                    <td><?php echo e($data->no_uji); ?> <br><?php echo e($data->no_kend); ?></td>
                    <td><?php echo e($data->pemilik); ?> <br> <?php echo e($data->perusahaan); ?> <br><?php echo e($data->alamat); ?></td>
                    <td><?php echo e($data->jenis_kendaraan); ?> <br><?php echo e($data->merk); ?> <br><?php echo e($data->tahun); ?></td>
                    <td>Rp. <?php echo number_format($data->retri,0,',','.'); ?></td>
                    <td>Rp. <?php echo number_format($data->periode,0,',','.'); ?> <br> Rp. <?php echo number_format($data->administrasi,0,',','.'); ?></td>
                    <td><?php echo e($data->catatan); ?></td>
                </tr>
                <!-- <tr>
                    <td colspan="5" rowspan="2" align="right"><b>Total</b></td>
                    <td>Rp. <?php echo number_format($data->retri,0,',','.'); ?></td>
                    <td>Rp. <?php echo number_format($data->leges,0,',','.'); ?></td>
                </tr>
                <tr>
                    <td colspan="5" align="center"><b>Rp. <?php echo number_format($data->retri+$data->leges,0,',','.'); ?></b></td>
                </tr> -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <!-- <td colspan="4" rowspan="2" align="right"><b>Jumlah Kendaraan : <?php echo e($no-1); ?> Unit/Kendaraan</b></td> -->
                    <td colspan="4" rowspan="2" align="right"><b>Jumlah Total : </b></td>
                    <td>Rp. <?php echo number_format($taksi->sum('retri'),0,',','.'); ?></td>
                    <td>
                        <table border="0">
                            <tr>
                                <td>Rp. <?php echo number_format($taksi->sum('periode'),0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <td>Rp. <?php echo number_format($taksi->sum('administrasi'),0,',','.'); ?></td>
                            </tr>
                        </table>
                    </td>
                    <td rowspan="2" align="right"><b>Jumlah Kendaraan : <?php echo e($no-1); ?> Unit/Kendaraan</b></td>
                </tr>
                <tr>
                    <td colspan="2" align="center"><b>Rp. <?php echo number_format($taksi->sum('retri')+$taksi->sum('periode')+$taksi->sum('administrasi'),0,',','.'); ?></b></td>
                    <!-- <td colspan="3" align="center"><b>Rp. <?php echo number_format($taksi->sum('retri')+$taksi->sum('leges'),0,',','.'); ?></b></td> -->
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_taksi/cetakpenerimaan.blade.php ENDPATH**/ ?>