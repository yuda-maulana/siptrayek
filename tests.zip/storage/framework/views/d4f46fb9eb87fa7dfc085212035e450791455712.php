<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Izin Usaha | Laporan Klasifikasi Retribusi Global</title>
    <link rel="icon" href="<?php echo e(asset('logo')); ?>/dishub.png" width="50px">
</head>

<body onload="window.print()">
    <div class="form-group">
        <h2 class="page-header" align="center">
            <h2 align="center"><u>REKAPITULASI PENERIMAAN BIAYA IZIN USAHA ANGKUTAN</u></h2><br>
            <small class="pull-right"></small>
        </h2>
        <table border="1" cellspacing="1" cellpadding="1" width="100%">
            <thead>
                <tr>
                    <td align="center" rowspan="3">Tanggal</td>
                    <td align="center" colspan="10">Klasifikasi Kendaraan</td>
                    <td align="center" rowspan="3">Jumlah Kendaraan</td>
                </tr>
                <tr>
                    <td align="center" colspan="5">Angkutan Penumpang</td>
                    <td align="center" colspan="5">Angkutan Barang</td>
                </tr>
                <tr>
                    <td align="center">0-8 Orang</td>
                    <td align="center">9-15 Orang</td>
                    <td align="center">16-25 Orang</td>
                    <td align="center">26 Orang lebih</td>
                    <td align="center">Jumlah</td>
                    <td align="center">0-5.000 Kg</td>
                    <td align="center">5.001-8.000 Kg</td>
                    <td align="center">8.001-15.000 Kg</td>
                    <td align="center">15.000 Kg lebih</td>
                    <td align="center">Jumlah</td>
                </tr>
                <?php $__currentLoopData = $klsusaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(Carbon\Carbon::parse($data->terbit)->isoFormat('D MMMM Y')); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($penumpang); ?></td>
                </tr>


            </thead>
            <tbody>

            </tbody>
        </table>
        <table border="0" align="left">
            <tr>
                <td></td>
            </tr>
            <tr>
                <td align="center">Mengetahui</td>
            </tr>
            <tr>
                <td colspan="3" align="center">
                    <font size=2>
                        KEPALA BIDANG ANGKUTAN<br>
                </td>
            </tr>
            <tr>
                <td height=70></td>
            </tr>
            <tr>
                <td colspan="3" align="center"><b><u>Ajat Sudrajat, ATD, MM</u></b></td>
            </tr>
            <tr>
                <td colspan="3" align="center">NIP. 196907051994031021</td>
            </tr>
        </table>
        <table border="0" align="right">
            <tr>
                <td align="center"></td>
            </tr>
            <tr>
                <td colspan="3" align="center">
                    <font size=3>
                        Tasikmalaya, <?php echo e(Carbon\Carbon::now()->isoFormat('D MMMM Y')); ?><br>
                        Kepala Seksi Bina Usaha Angkutan
                </td>
            </tr>
            <tr>
                <td height=70></td>
            </tr>
            <tr>
                <td colspan="3" align="center"><b><u>Denny Iskandar, A.Md</u></b></td>
            </tr>
            <tr>
                <td colspan="3" align="center">NIP. 196702121990021000</td>
            </tr>
        </table>
        <br><br>

    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_usaha/klasifikasidetail.blade.php ENDPATH**/ ?>