
<?php $__env->startSection('title', 'Tambah Buku Penerimaan'); ?>
<?php $__env->startSection('content'); ?>

<form action="/v_bukubesar/insert" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <section class="content">
        <div class="row">
            <div class="col-md-6">
                <div class="box box-primary">
                    <!-- <form role="form"> -->
                    <div class="box-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="tahun">Tahun</label>
                                    <input type="text" name="tahun" class="form-control" id="tahun" value="<?php echo e(old('tahun')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="target_id">Target</label>
                                    <select class="form-control" name="target_id" id="target_id">
                                        <option disabled value>Pilih Lintasan</option>
                                        <?php $__currentLoopData = $target; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->tahun); ?> : Rp. <?php echo number_format($item->target3,0,',','.'); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="kode_rek">Kode Rek</label>
                                    <input type="text" name="kode_rek" class="form-control" id="kode_rek" value="<?php echo e(old('kode_rek')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['kode_rek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="nama_rek">Nama Rek</label>
                                    <input type="text" name="nama_rek" class="form-control" id="nama_rek" value="<?php echo e(old('nama_rek')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['nama_rek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="tgl_terima">Tanggal Terima</label>
                                    <input type="date" name="tgl_terima" class="form-control" id="tgl_terima" value="<?php echo e(old('tgl_terima')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['tgl_terima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="jml_terima">Jumlah Terima</label>
                                    <input type="text" name="jml_terima" class="form-control" id="jml_terima" value="<?php echo e(old('jml_terima')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['jml_terima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="tgl_setor">Tanggal Setor</label>
                                    <input type="date" name="tgl_setor" class="form-control" id="tgl_setor" value="<?php echo e(old('tgl_setor')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['tgl_setor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="no_setor">No Setor</label>
                                    <input type="text" name="no_setor" class="form-control" id="no_setor" value="<?php echo e(old('no_setor')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['no_setor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="jm_tg_i">Jumlah Tgl Ini</label>
                                    <input type="text" name="jm_tg_i" class="form-control" id="jm_tg_i" value="<?php echo e(old('jm_tg_i')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['jm_tg_i'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="jm_tg_l">Jumlah Tgl Lalu</label>
                                    <input type="text" name="jm_tg_l" class="form-control" id="jm_tg_l" value="<?php echo e(old('jm_tg_l')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['jm_tg_l'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="jm_stg_i">Jumlah s.d Tgl Ini</label>
                                    <input type="text" name="jm_stg_i" class="form-control" id="jm_stg_i" value="<?php echo e(old('jm_stg_i')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['jm_stg_i'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="jm_bl_i">Jumlah Bulan Ini</label>
                                    <input type="text" name="jm_bl_i" class="form-control" id="jm_bl_i" value="<?php echo e(old('jm_bl_i')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['jm_bl_i'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="jm_bl_l">Jumlah Bulan Lalu</label>
                                    <input type="text" name="jm_bl_l" class="form-control" id="jm_bl_l" value="<?php echo e(old('jm_bl_l')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['jm_bl_l'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="jm_sbl_i">Jumlah s.d Bulan Ini</label>
                                    <input type="text" name="jm_sbl_i" class="form-control" id="jm_sbl_i" value="<?php echo e(old('jm_sbl_i')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['jm_sbl_i'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button class="btn btn-success">Simpan</button>
                        <a href="bukubesar" class="btn btn-danger">Batal</a>
                    </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </section>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_bukubesar/add.blade.php ENDPATH**/ ?>