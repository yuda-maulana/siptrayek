<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SK No <?php echo e($trayek->no_sk); ?></title>
    <link rel="icon" href="<?php echo e(asset('logo')); ?>/dishub.png" width="50px">

</head>

<body>
    <table border="0" align="center" cellpadding=1 cellspacing=0>
        <tr>
            <td align="center" width=100 colspan="3"><img src="<?php echo e(asset('logo')); ?>/pemkot.png" width="70" height="70"></td>
            <td align="center" width=600>
                <font size="4"><b>PEMERINTAH KOTA TASIKMALAYA</font></b><br>
                <font size="6"><b>DINAS PERHUBUNGAN</font></b><br>
                <font size="4"><b>KOTA TASIKMALAYA</font></b><br>
                <font>Jl. Ir. H. Djuanda No. 191 Telp. (0265) 329025 - 325187 Kota Tasikmalaya</font><br>
                <font>Website : </font>
                <font style="color: blue;"><u>http://dishub.tasikmalayakota.go.id</u></font><br>
            <td align="center" width=100 colspan=""></td>
            </td>
        </tr>
        <tr>
            <td colspan="5">
                <hr size="3" color="black" width="100%">
                <!-- <hr size="2" color="black" width="100%"> -->
            </td>
        </tr>
    </table>
</body>

</html><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/layout/kop.blade.php ENDPATH**/ ?>