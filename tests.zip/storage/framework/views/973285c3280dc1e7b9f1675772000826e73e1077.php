
<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <a href="edit/<?php echo e(Auth::user()->id); ?>" class="btn btn-warning btn-sm">Edit Data</a>
                </div>
                <!-- /.box-header -->
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Nama</th>
                                <td><?php echo e(Auth::user()->name); ?></td>
                            </tr>
                            <tr>
                                <th>NIP</th>
                                <td><?php echo e(Auth::user()->nip); ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo e(Auth::user()->email); ?></td>
                            </tr>
                            <!-- <tr>
                                <th>Password</th>
                                <td><?php echo e(Auth::user()->password); ?></td>
                            </tr> -->
                            <tr>
                                <th>Foto</th>
                                <td><img src="<?php echo e(asset('foto/' . Auth::user()->foto )); ?>" width="100px" alt="Foto tidak tersedia"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\dishub\resources\views/v_profile/profile.blade.php ENDPATH**/ ?>