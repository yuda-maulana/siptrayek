
<?php $__env->startSection('title', 'Ijin Insidentil'); ?>

<?php $__env->startSection('content'); ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>No Uji</th>
            <th>No Kend.</th>
            <th>No Bend</th>
            <th>Nama Pemilik</th>
            <th>Merk</th>
            <th>Tahun</th>
            <th>Habis Uji</th>
            <th>Terbit</th>
            <th>Maksud</th>
            <th>Tujuan</th>
            <th>Tanggal Perjalanan</th>
        </tr>
    </thead>
    <tbody>
        <?php $no = 1; ?>
        <?php $__currentLoopData = $insidentil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($data->no_uji); ?></td>
            <td><?php echo e($data->no_kend); ?></td>
            <td><?php echo e($data->no_bend); ?></td>
            <td><?php echo e($data->nama_pemilik); ?></td>
            <td><?php echo e($data->merk); ?></td>
            <td><?php echo e($data->tahun); ?></td>
            <td><?php echo e($data->habis_uji); ?></td>
            <td><?php echo e($data->terbit); ?></td>
            <td><?php echo e($data->maksud); ?></td>
            <td><?php echo e($data->tujuan); ?></td>
            <td><?php echo e($data->tgl_awal_perjalanan); ?> s/d <?php echo e($data->tgl_akhir_perjalanan); ?> </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dishub\resources\views/perijinan/insidentil.blade.php ENDPATH**/ ?>