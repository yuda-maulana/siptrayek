<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Izin Usaha | Laporan Kegiatan Usaha</title>
    <link rel="icon" href="<?php echo e(asset('logo')); ?>/dishub.png" width="50px">
</head>

<body onload="window.print()">
    <div class="form-group">
        <h2 class="page-header" align="center">
            <h2 align="center"><u>DAFTAR IZIN USAHA YANG DIPROSES</u></h2><br>
            <small class="pull-right"></small>
        </h2>
        <table border="1" cellspacing="1" cellpadding="1" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No. Uji <br> No. Kend</th>
                    <th>Pemilik <br> Perusahaan <br> Alamat</th>
                    <th>Jenis Kendaraan / Layanan <br> Keterangan / Merk / Tahun Kendaraan</th>
                    <th>No Rangka / Mesin <br> JBB (kg) / Seat (orang)</th>
                    <th>No SK <br> Masa Berlaku</th>
                    <th>No KP <br> Masa Berlaku</th>
                    <th>Tgl. Terbit / NIK</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $usaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($no++); ?></td>
                    <td><?php echo e($data->no_uji); ?> <br><?php echo e($data->no_kend); ?></td>
                    <td><?php echo e($data->pemilik); ?> <br> <?php echo e($data->perusahaan); ?> <br><?php echo e($data->alamat); ?></td>
                    <td><?php echo e($data->jenis); ?> / <?php echo e($data->layanan); ?> <br><?php echo e($data->merk); ?> / <?php echo e($data->tahun); ?> <br><?php echo e($data->catatan); ?></td>
                    <td><?php echo e($data->rangka); ?> / <?php echo e($data->mesin); ?> <br> <?php echo e($data->jbb); ?> / <?php echo e($data->orang); ?></td>
                    <td><?php echo e($data->no_sk); ?> <br> <?php echo e(Carbon\Carbon::parse($data->tgl_sk)->isoFormat('D MMMM Y')); ?> s/d <?php echo e(Carbon\Carbon::parse($data->akh_sk)->isoFormat('D MMMM Y')); ?></td>
                    <td><?php echo e($data->no_kp); ?> <br> <?php echo e(Carbon\Carbon::parse($data->tgl_kp)->isoFormat('D MMMM Y')); ?> s/d <?php echo e(Carbon\Carbon::parse($data->akh_kp)->isoFormat('D MMMM Y')); ?></td>
                    <td><?php echo e(Carbon\Carbon::parse($data->terbit)->isoFormat('D MMMM Y')); ?> <br><?php echo e($data->urut); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="8" align="center"><b>Jumlah Kendaraan : <?php echo e($no-1); ?> Unit/Kendaraan</b></td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_usaha/cetaklaporan.blade.php ENDPATH**/ ?>