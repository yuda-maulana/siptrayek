
<?php $__env->startSection('title', 'Detail PAD'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-xs-15">
            <div class="box">
                <div class="box-header">
                    <a href="/v_pad/edit/<?php echo e($pad->id); ?>" class="btn btn-sm btn-warning pull-right">Edit Data</a>
                    <a href="/v_pad/cetaklaporan/<?php echo e($pad->id); ?>" class="btn btn-sm btn-primary pull-left" target="_blank">Cetak Bukti Setoran</a>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Kode Rekening</th>
                                <td><?php echo e($pad->kod_rek); ?></td>
                            </tr>
                            <tr>
                                <th>No Rekening</th>
                                <td><?php echo e($pad->no_rek); ?></td>
                            </tr>
                            <tr>
                                <th>Nama Rekening</th>
                                <td><?php echo e($pad->nama_rek); ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal</th>
                                <td><?php echo e(Carbon\Carbon::parse($pad->tanggal)->isoFormat('D MMMM Y')); ?></td>
                            </tr>
                            <tr>
                                <th>No Bukti</th>
                                <td><?php echo e($pad->no_bukti); ?></td>
                            </tr>
                            <tr>
                                <th>Grup</th>
                                <td><?php echo e($pad->grup); ?></td>
                            </tr>
                            <tr>
                                <th>Urut</th>
                                <td><?php echo e($pad->urut); ?></td>
                            </tr>
                            <tr>
                                <th>Uraian</th>
                                <td><?php echo e($pad->uraian); ?></td>
                            </tr>
                            <tr>
                                <th>Unit</th>
                                <td><?php echo e($pad->unit); ?></td>
                            </tr>
                            <tr>
                                <th>Retribusi</th>
                                <td>Rp. <?php echo number_format($pad->retribusi,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Jumlah</th>
                                <td>Rp. <?php echo number_format($pad->jumlah,0,',','.'); ?></td>
                            </tr>

                        </tbody>
                    </table>
                </div>
                <div class="box-footer">
                    <a href="../pad" class="btn btn-success btn-sm ">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_pad/detail.blade.php ENDPATH**/ ?>