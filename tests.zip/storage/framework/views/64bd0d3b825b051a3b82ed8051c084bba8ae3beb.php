
<?php $__env->startSection('title', 'Detail Izin Insidentil'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <a href="/v_insidentil/edit/<?php echo e($insidentil->id); ?>" class="btn btn-sm btn-warning pull-right">Edit Data</a>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Tanggal</th>
                                <td><?php echo e($insidentil->no_uji); ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal</th>
                                <td><?php echo e($insidentil->no_kend); ?></td>
                            </tr>
                            <tr>
                                <th>No. Bend</th>
                                <td><?php echo e($insidentil->no_bend); ?></td>
                            </tr>
                            <tr>
                                <th>Nama Pemilik</th>
                                <td><?php echo e($insidentil->nama_pemilik); ?></td>
                            </tr>
                            <tr>
                                <th>Alamat</th>
                                <td><?php echo e($insidentil->alamat); ?></td>
                            </tr>
                            <tr>
                                <th>Merk</th>
                                <td><?php echo e($insidentil->merk); ?></td>
                            </tr>
                            <tr>
                                <th>Tahun</th>
                                <td><?php echo e($insidentil->tahun); ?></td>
                            </tr>
                            <tr>
                                <th>Trayek Dimohon</th>
                                <td><?php echo e($insidentil->habis_uji); ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal Terbit</th>
                                <td><?php echo e($insidentil->terbit); ?></td>
                            </tr>
                            <tr>
                                <th>Maksud</th>
                                <td><?php echo e($insidentil->maksud); ?></td>
                            </tr>
                            <tr>
                                <th>Tujuan</th>
                                <td><?php echo e($insidentil->tujuan); ?></td>
                            </tr>
                            <tr>
                                <th>Retribusi</th>
                                <td><?php echo e($insidentil->retribusi); ?></td>
                            </tr>
                            <tr>
                                <th>Leges</th>
                                <td><?php echo e($insidentil->leges); ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal Perjalanan</th>
                                <td><?php echo e($insidentil->tgl_awal_perjalanan); ?> s/d <?php echo e($insidentil->tgl_akhir_perjalanan); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="box-footer">
                    <a href="../insidentil" class="btn btn-success btn-sm ">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\dishub\resources\views/v_insidentil/detail.blade.php ENDPATH**/ ?>