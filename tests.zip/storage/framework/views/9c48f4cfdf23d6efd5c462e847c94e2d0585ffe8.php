<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <style>
        table.static {
            position: relative;

            border: 1px solid #543535;
        }
    </style>
    <title>Cetak Data</title>
</head>

<body>
    <div class="form-group">
        <h2 class="page-header" align="center">
            <i class="fa fa-globe"></i> Laporan Lintasan Trayek <br><br>
            <small class="pull-right">Tanggal : <?php echo e(date('d-M-Y')); ?></small>
        </h2>
        <table class="static" align="center" rules="all" border="1px" style="width: 95%;">
            <tr>
                <th>No</th>
                <th>Kode Lintasan</th>
                <th>Lintasan Trayek</th>
                <th>Alokasi</th>
                <th>Rute</th>
            </tr>
            <?php $no = 1; ?>
            <?php $__currentLoopData = $lintrayek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($data->kode); ?></td>
                <td><?php echo e($data->lintasan); ?></td>
                <td><?php echo e($data->alokasi); ?></td>
                <td><?php echo e($data->rute); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views//v_lintrayek/printpdf.blade.php ENDPATH**/ ?>