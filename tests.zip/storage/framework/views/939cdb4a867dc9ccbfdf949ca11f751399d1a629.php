
<?php $__env->startSection('title', 'Detail Lintasan Trayek'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <h4 class="box-title">Data Kendaraan</h4>
                    <a href="/v_trayek/edit/<?php echo e($trayek->id); ?>" class="btn btn-sm btn-warning pull-right">Edit Data</a>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Tanggal Terbit</th>
                                <td><?php echo e(Carbon\Carbon::parse($trayek->terbit)->isoFormat('D MMMM Y')); ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <?php if(!(strtotime($trayek->tgl_sk) <= time() AND time()>= strtotime($trayek->akhir_sk))): ?>
                                    <td><span class="label label-success">Aktif</span></td>
                                    <?php else: ?>
                                    <td><span class="label label-danger">Tidak Aktif</span></td>
                                    <?php endif; ?>
                            </tr>
                            <tr>
                                <th>No. Urut</th>
                                <td><?php echo e($trayek->urut); ?></td>
                            </tr>
                            <tr>
                                <th>Lintasan Trayek</th>
                                <td><?php echo e($trayek->lintrayek->kode); ?> : <?php echo e($trayek->lintrayek->lintasan); ?></td>
                            </tr>
                            <tr>
                                <th>Alokasi</th>
                                <td><?php echo e($trayek->lintrayek->alokasi); ?></td>
                            </tr>
                            <tr>
                                <th>No. Uji / No. Kend / No. Bend</th>
                                <td><?php echo e($trayek->no_uji); ?> / <?php echo e($trayek->no_kend); ?> / <?php echo e($trayek->no_bend); ?></td>
                            </tr>
                            <tr>
                                <th>Nama Pemilik</th>
                                <td><?php echo e($trayek->pemilik); ?></td>
                            </tr>
                            <tr>
                                <th>Perusahaan</th>
                                <td><?php echo e($trayek->perusahaan); ?></td>
                            </tr>
                            <tr>
                                <th>Alamat</th>
                                <td><?php echo e($trayek->alamat); ?></td>
                            </tr>
                            <tr>
                                <th>Pimpinan</th>
                                <td><?php echo e($trayek->pimpinan); ?></td>
                            </tr>
                            <tr>
                                <th>No. Rangka / Mesin</th>
                                <td><?php echo e($trayek->no_rangka); ?> / <?php echo e($trayek->mesin); ?></td>
                            </tr>
                            <tr>
                                <th>Seat / Barang</th>
                                <td><?php echo e($trayek->seat); ?> Orang / <?php echo e($trayek->barang); ?> kg</td>
                            </tr>
                            <tr>
                                <th>Merk / Tahun</th>
                                <td><?php echo e($trayek->merk); ?> / <?php echo e($trayek->tahun); ?></td>
                            </tr>
                            <tr>
                                <th>Jenis Kendaraan</th>
                                <td><?php echo e($trayek->jeniskend->jnskend); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="box-footer">
                    <a href="../trayek" class="btn btn-success btn-sm ">Kembali</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <h4 class="box-title">Surat Keputusan dan Kartu Pengawasan</h4>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Nomor SK</th>
                                <td><?php echo e($trayek->no_sk); ?> | <a href="../cetaksk/<?php echo e($trayek->id); ?>" target="_blank" class="btn btn-info btn-sm ">Cetak SK</a></td>
                                <th>Nomor KP</th>
                                <td><?php echo e($trayek->no_kp); ?> | <a href="../cetakkp/<?php echo e($trayek->id); ?>" target="_blank" class="btn btn-info btn-sm ">Cetak KP</a></td>
                            </tr>
                            <tr>
                                <th>Berlaku SK</th>
                                <td><?php echo e(Carbon\Carbon::parse($trayek->tgl_sk)->isoFormat('D MMMM Y')); ?> s/d <?php echo e(Carbon\Carbon::parse($trayek->akhir_sk)->isoFormat('D MMMM Y')); ?></td>
                                <th>Berlaku KP</th>
                                <td><?php echo e(Carbon\Carbon::parse($trayek->tgl_kp)->isoFormat('D MMMM Y')); ?> s/d <?php echo e(Carbon\Carbon::parse($trayek->akhir_kp)->isoFormat('D MMMM Y')); ?></td>
                            </tr>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <h4 class="box-title">Uraian Biaya</h4>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Retribusi SK</th>
                                <td>Rp. <?php echo number_format($trayek->ret_sk,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Retribusi KP</th>
                                <td>Rp. <?php echo number_format($trayek->ret_kp,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Total Retribusi</th>
                                <td>Rp. <?php echo number_format($trayek->ret_sk+$trayek->ret_kp,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Denda Periode</th>
                                <td>Rp. <?php echo number_format($trayek->denda_periode,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Denda Adm.</th>
                                <td>Rp. <?php echo number_format($trayek->denda_admin,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Jumlah Total</th>
                                <td>Rp. <?php echo number_format($trayek->ret_sk+$trayek->ret_kp+$trayek->denda_periode+$trayek->denda_admin,0,',','.'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Jenis Permohonan</th>
                                <td><?php echo e($trayek->catatan); ?></td>
                            </tr>
                            <tr>
                                <th>Keterangan</th>
                                <td><?php echo e($trayek->ket); ?> <?php echo e($trayek->ket1); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_trayek/detail.blade.php ENDPATH**/ ?>