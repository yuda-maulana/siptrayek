
<?php $__env->startSection('title', 'Detail Rekomendasi'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <a href="/v_rekomendasi/edit/<?php echo e($rekomendasi->id); ?>" class="btn btn-sm btn-warning pull-right">Edit Data</a>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Tanggal</th>
                                <td><?php echo e(Carbon\Carbon::parse($rekomendasi->tanggal)->isoFormat('D MMMM Y')); ?></td>
                            </tr>
                            <tr>
                                <th>Urut</th>
                                <td><?php echo e($rekomendasi->urut); ?></td>
                            </tr>
                            <tr>
                                <th>No. Bend</th>
                                <td><?php echo e($rekomendasi->no_bend); ?></td>
                            </tr>
                            <tr>
                                <th>Jenis Pelayanan</th>
                                <td><?php echo e($rekomendasi->layanan); ?></td>
                            </tr>
                            <tr>
                                <th>Pemilik</th>
                                <td><?php echo e($rekomendasi->pemilik); ?></td>
                            </tr>
                            <tr>
                                <th>Perusahaan</th>
                                <td><?php echo e($rekomendasi->perusahaan); ?></td>
                            </tr>
                            <tr>
                                <th>Alamat</th>
                                <td><?php echo e($rekomendasi->alamat); ?></td>
                            </tr>
                            <tr>
                                <th>Jenis Permohonan</th>
                                <td><?php echo e($rekomendasi->mohon); ?></td>
                            </tr>
                            <tr>
                                <th>Sifat Pelayanan</th>
                                <td><?php echo e($rekomendasi->sifat); ?></td>
                            </tr>
                            <tr>
                                <th>Jenis / Jumlah Kendaraan</th>
                                <td><?php echo e($rekomendasi->jenis); ?> / <?php echo e($rekomendasi->jumlah); ?></td>
                            </tr>
                            <tr>
                                <th>Trayek Dimohon</th>
                                <td><?php echo e($rekomendasi->trayek); ?></td>
                            </tr>
                            <tr>
                                <th>Retribusi</th>
                                <td>Rp. <?php echo number_format($rekomendasi->retri,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal Terbit</th>
                                <td><?php echo e(Carbon\Carbon::parse($rekomendasi->terbit)->isoFormat('D MMMM Y')); ?></td>
                            </tr>
                            <tr>
                                <th>Catatan</th>
                                <td><?php echo e($rekomendasi->catatan); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="box-footer">
                    <a href="../rekomendasi" class="btn btn-success btn-sm ">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_rekomendasi/detail.blade.php ENDPATH**/ ?>