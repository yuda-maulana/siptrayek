
<?php $__env->startSection('title', 'Siswa'); ?>
<?php $__env->startSection('content'); ?>

<a href="/siswa/print" target="_blank" class="btn btn-primary">Print to Printer</a>
<a href="/siswa/printpdf" target="_blank" class="btn btn-success">Print to PDF</a>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>NIS</th>
            <th>Nama Siswa</th>
            <th>Kelas</th>
            <th>Mata Pelajaran</th>
        </tr>
    </thead>
    <tbody>
        <?php $no = 1 ?>
        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($data->nis); ?></td>
            <td><?php echo e($data->nama_siswa); ?></td>
            <td><?php echo e($data->kelas); ?></td>
            <td><?php echo e($data->mapel); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dishub\resources\views/siswa.blade.php ENDPATH**/ ?>