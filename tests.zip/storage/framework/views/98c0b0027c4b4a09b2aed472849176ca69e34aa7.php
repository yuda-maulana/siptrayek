
<?php $__env->startSection('title', 'Detail Izin Operasi Taksi'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <h4 class="box-title">Data Kendaraan</h4>
                    <a href="/v_taksi/edit/<?php echo e($taksi->id); ?>" class="btn btn-sm btn-warning pull-right">Edit Data</a>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>No. Induk</th>
                                <td><?php echo e($taksi->urut); ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal Terbit</th>
                                <td><?php echo e(Carbon\Carbon::parse($taksi->terbit)->isoFormat('D MMMM Y')); ?></td>
                            </tr>
                            <!-- <tr>
                                <th>Status</th>
                                <?php if(!(strtotime($taksi->tgl_sk) <= time() AND time()>= strtotime($taksi->akhir_sk))): ?>
                                    <td><span class="label label-success">Aktif</span></td>
                                    <?php else: ?>
                                    <td><span class="label label-danger">Tidak Aktif</span></td>
                                    <?php endif; ?>
                            </tr> -->
                            <tr>
                                <th>No. Uji / No. Kend / No. Bend</th>
                                <td><?php echo e($taksi->no_uji); ?> / <?php echo e($taksi->no_kend); ?> / <?php echo e($taksi->no_bend); ?></td>
                            </tr>
                            <tr>
                                <th>Nama Pemilik</th>
                                <td><?php echo e($taksi->pemilik); ?></td>
                            </tr>
                            <tr>
                                <th>Perusahaan</th>
                                <td><?php echo e($taksi->perusahaan); ?></td>
                            </tr>
                            <tr>
                                <th>Alamat</th>
                                <td><?php echo e($taksi->alamat); ?></td>
                            </tr>
                            <tr>
                                <th>Pimpinan</th>
                                <td><?php echo e($taksi->pimpinan); ?></td>
                            </tr>
                            <tr>
                                <th>No. Rangka / Mesin</th>
                                <td><?php echo e($taksi->rangka); ?> / <?php echo e($taksi->mesin); ?></td>
                            </tr>
                            <tr>
                                <th>Seat / Barang</th>
                                <td><?php echo e($taksi->orang); ?> Orang / <?php echo e($taksi->barang); ?> kg</td>
                            </tr>
                            <tr>
                                <th>Merk / Tahun</th>
                                <td><?php echo e($taksi->merk); ?> / <?php echo e($taksi->tahun); ?></td>
                            </tr>
                            <tr>
                                <th>Jenis Kendaraan</th>
                                <td><?php echo e($taksi->jenis_kendaraan); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="box-footer">
                    <a href="../taksi" class="btn btn-success btn-sm ">Kembali</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <h4 class="box-title">Surat Keputusan dan Kartu Pengawasan</h4>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Nomor SK</th>
                                <td><?php echo e($taksi->no_sk); ?> | <a href="../cetaksk/<?php echo e($taksi->id); ?>" target="_blank" class="btn btn-info btn-sm ">Cetak SK</a></td>
                                <th>Nomor KP</th>
                                <td><?php echo e($taksi->no_kp); ?> | <a href="../cetakkp/<?php echo e($taksi->id); ?>" target="_blank" class="btn btn-info btn-sm ">Cetak KP</a></td>
                            </tr>
                            <tr>
                                <th>Berlaku SK</th>
                                <td><?php echo e(Carbon\Carbon::parse($taksi->tgl_sk)->isoFormat('D MMMM Y')); ?> s/d <?php echo e(Carbon\Carbon::parse($taksi->akhir_sk)->isoFormat('D MMMM Y')); ?></td>
                                <th>Berlaku KP</th>
                                <td><?php echo e(Carbon\Carbon::parse($taksi->tgl_kp)->isoFormat('D MMMM Y')); ?> s/d <?php echo e(Carbon\Carbon::parse($taksi->akhir_kp)->isoFormat('D MMMM Y')); ?></td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <h4 class="box-title">Uraian Biaya</h4>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Retribusi</th>
                                <td>Rp. <?php echo number_format($taksi->retri,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Denda Periode</th>
                                <td>Rp. <?php echo number_format($taksi->periode,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Denda Adm.</th>
                                <td>Rp. <?php echo number_format($taksi->administrasi,0,',','.'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Jenis Permohonan</th>
                                <td><?php echo e($taksi->catatan); ?></td>
                            </tr>
                            <tr>
                                <th>Keterangan</th>
                                <td><?php echo e($taksi->ket); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_taksi/detail.blade.php ENDPATH**/ ?>