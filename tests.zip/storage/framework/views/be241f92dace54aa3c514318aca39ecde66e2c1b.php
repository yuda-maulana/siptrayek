<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekomendasi | Laporan Kegiatan Rekomendasi</title>
    <link rel="icon" href="<?php echo e(asset('logo')); ?>/dishub.png" width="50px">
</head>

<body onload="window.print()">
    <div class="form-group">
        <h2 class="page-header" align="center">
            <h2 align="center"><u>DAFTAR REKOMENDASI YANG DIPROSES</u></h2><br>
            <small class="pull-right"></small>
        </h2>
        <table border="1" cellspacing="1" cellpadding="1" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal <br> No. Bend</th>
                    <th>Nama <br> Perusahaan <br> Alamat</th>
                    <th>Jenis / Sifat Pelayanan <br>Trayek Dimohon</th>
                    <th>Jenis / Jumlah Kendaraan</th>
                    <th>Tgl. Terbit / NIK / Keterangan</th>
                </tr>
            </thead>

            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($no++); ?></td>
                    <td><?php echo e(Carbon\Carbon::parse($data->tanggal)->isoFormat('D MMMM Y')); ?> <br> <?php echo e($data->no_bend); ?></td>
                    <td><?php echo e($data->pemilik); ?> <br> <?php echo e($data->perusahaan); ?> <br><?php echo e($data->alamat); ?></td>
                    <td><?php echo e($data->layanan); ?> <br><?php echo e($data->sifat); ?> <br><?php echo e($data->trayek); ?></td>
                    <td><?php echo e($data->jenis); ?> <br> <?php echo e($data->jumlah); ?></td>
                    <td><?php echo e(Carbon\Carbon::parse($data->terbit)->isoFormat('D MMMM Y')); ?> <br><?php echo e($data->urut); ?> <br><?php echo e($data->catatan); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="7" align="center"><b>Jumlah Kendaraan : <?php echo e($no-1); ?> Unit/Kendaraan</b></td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_rekomendasi/cetaklaporan.blade.php ENDPATH**/ ?>