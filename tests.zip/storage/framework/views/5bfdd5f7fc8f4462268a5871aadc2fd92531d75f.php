
<?php $__env->startSection('title', 'Detail Lintasan Trayek'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-xs-15">
            <div class="box">
                <div class="box-header">
                    <a href="/v_lintrayek/edit/<?php echo e($lintrayek->id); ?>" class="btn btn-sm btn-warning pull-right">Edit Data</a>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Kode Lintasan</th>
                                <td><?php echo e($lintrayek->kode); ?></td>
                            </tr>
                            <tr>
                                <th>Lintasan Trayek</th>
                                <td><?php echo e($lintrayek->lintasan); ?></td>
                            </tr>
                            <tr>
                                <th>Alokasi</th>
                                <td><?php echo e($lintrayek->alokasi); ?></td>
                            </tr>
                            <tr>
                                <th>Rute</th>
                                <td><?php echo e($lintrayek->rute); ?></td>
                            </tr>

                        </tbody>
                    </table>
                </div>
                <div class="box-footer">
                    <a href="../lintrayek" class="btn btn-success btn-sm ">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\dishub\resources\views/v_lintrayek/detail.blade.php ENDPATH**/ ?>