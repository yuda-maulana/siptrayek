
<?php $__env->startSection('title', 'Rekomendasi'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('pesan')): ?>
<div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-check"></i> Berhasil!</h4>
    <?php echo e(session('pesan')); ?>

</div>
<?php endif; ?>
<section class="content">
    <div class="row">
        <div class="col-xs-15">
            <div class="box">
                <div class="box-header">
                    <a href="add" class="btn btn-success btn-sm">Tambah Data</a>
                    <div class="btn-group">
                        <button type="button" class="btn btn-primary btn-sm">Cetak Laporan</button>
                        <button type="button" class="btn btn-primary dropdown-toggle btn-sm" data-toggle="dropdown" aria-expanded="false">
                            <span class="caret"></span>
                            <span class="sr-only">Toggle Dropdown</span>
                        </button>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="printpdf" target="_blank">Laporan Keseluruhan</a></li>
                            <!-- <li><a href="#">Another action</a></li>
                            <li><a href="#">Something else here</a></li>
                            <li class="divider"></li>
                            <li><a href="#">Separated link</a></li> -->
                        </ul>
                    </div>
                    <div class="box-tools">
                        <form action="/v_rekomendasi/rekomendasi" method="get">
                            <div class="input-group input-group-sm" style="width: 180px;">
                                <input type="text" name="search" class="form-control" placeholder="Cari berdasarkan nama pemilik">
                                <div class="input-group-btn">
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>


                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>No. Bend</th>
                            <th>Nama Pemilik</th>
                            <th>Perusahaan / Alamat</th>
                            <!-- <th>Jenis / Sifat Pelayanan</th>
                            <th>Jenis / Jumlah Kendaraan</th> -->
                            <!-- <th>Retribusi | Leges</th> -->
                            <!-- <th>Trayek yang dimohon</th>
                               <th>Ket</th> -->
                            <th>Tgl. Terbit</th>

                            <th>Aksi</th>
                        </tr>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($data->tgl_rekom)->format('d/m/Y')); ?></td>
                            <td><?php echo e($data->no_bend); ?></td>
                            <td><?php echo e($data->pemilik); ?></td>
                            <td><?php echo e($data->perusahaan); ?> / <?php echo e($data->alamat); ?></td>
                            <!-- <td><?php echo e($data->jns_pelayanan); ?> / <?php echo e($data->sifat_pelayanan); ?></td>
                            <td><?php echo e($data->jns_kendaraan); ?> / <?php echo e($data->jmlh_kendaraan); ?></td> -->
                            <!-- <td><?php echo e($data->trayek_dimohon); ?></td>
                          
                            <td><?php echo e($data->keterangan); ?></td> -->
                            <!-- <td><?php echo e($data->retribusi); ?> | <?php echo e($data->leges); ?></td> -->
                            <td><?php echo e(Carbon\Carbon::parse($data->tgl_terbit)->format('d/m/Y')); ?></td>
                            <td>
                                <a href="/v_rekomendasi/detail/<?php echo e($data->id); ?>" class="btn btn-sm btn-info">Detail</a>
                                <a href="/v_rekomendasi/edit/<?php echo e($data->id); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete<?php echo e($data->id); ?>">
                                    Hapus
                                </button>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                </div>
                <div class="box-footer clearfix">
                    <div class="d-flex justify-content-center">
                        <p>Halaman saat ini : <b><?php echo e($rekomendasi->currentPage()); ?></b></p>
                        <p>Jumlah Data : <b><?php echo e($rekomendasi->total()); ?></b></p>
                        <p>Data perhalaman : <b><?php echo e($rekomendasi->perPage()); ?></b></p>
                        <?php echo e($rekomendasi->links()); ?>

                    </div>
                </div>
                <!-- /.box-body -->

            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal modal-danger fade" id="delete<?php echo e($data->id); ?>">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo e($data->pemilik); ?></h4>
            </div>
            <div class="modal-body">
                <p>Apakah anda yakin ingin menghapus data ini?</p>
            </div>
            <div class="modal-footer">
                <a href="" class="btn btn-outline pull-left" data-dismiss="modal">Tidak</a>
                <a href="/v_rekomendasi/delete/<?php echo e($data->id); ?>" class="btn btn-outline">Ya</a>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\dishub\resources\views/v_rekomendasi/rekomendasi.blade.php ENDPATH**/ ?>