
<?php $__env->startSection('title', 'Khusus'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('pesan')): ?>
<div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-check"></i> Berhasil!</h4>
    <?php echo e(session('pesan')); ?>

</div>
<?php endif; ?>
<section class="content">
    <div class="row">
        <div class="col-xs-15">
            <div class="box">
                <div class="box-header">
                    <a href="add" class="btn btn-success btn-sm">Tambah Data</a>
                    <div class="btn-group">
                        <button type="button" class="btn btn-primary btn-sm">Cetak Laporan</button>
                        <button type="button" class="btn btn-primary dropdown-toggle btn-sm" data-toggle="dropdown" aria-expanded="false">
                            <span class="caret"></span>
                            <span class="sr-only">Toggle Dropdown</span>
                        </button>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="formkegiatan">Laporan Kegiatan</a></li>
                            <li><a href="formpenerimaan">Penerimaan Biaya</a></li>
                        </ul>
                    </div>
                    <div class="box-tools">
                        <br>
                        <form action="/v_khusus/khusus" method="get">
                            <div class="input-group input-group-sm" style="width: 300px;">
                                <input type="text" name="search" class="form-control" placeholder="Cari berdasarkan nama pemilik, perusahaan, dan jenis permohonan">
                                <div class="input-group-btn">
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>


                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tr>
                            <th>No</th>
                            <th>No. Uji / No. Kend</th>
                            <th>Pemilik</th>
                            <th>Perusahaan</th>
                            <th>Tanggal Terbit</th>
                            <th>Aksi</th>
                        </tr>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $khusus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($data->no_uji); ?> / <?php echo e($data->no_kend); ?></td>
                            <td><?php echo e($data->pemilik); ?></td>
                            <td><?php echo e($data->perusahaan); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($data->terbit)->isoFormat('D MMMM Y')); ?></td>
                            <td>
                                <a href="/v_khusus/detail/<?php echo e($data->id); ?>" class="btn btn-sm btn-info">Detail</a>
                                <a href="/v_khusus/edit/<?php echo e($data->id); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete<?php echo e($data->id); ?>">
                                    Hapus
                                </button>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                </div>
                <div class="box-footer clearfix">
                    <div class="d-flex justify-content-center">
                        <p>Halaman saat ini : <b><?php echo e($khusus->currentPage()); ?></b></p>
                        <p>Jumlah Data : <b><?php echo e($khusus->total()); ?></b></p>
                        <p>Data perhalaman : <b><?php echo e($khusus->perPage()); ?></b></p>
                        <?php echo e($khusus->links()); ?>

                    </div>
                </div>
                <!-- /.box-body -->

            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php $__currentLoopData = $khusus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal modal-danger fade" id="delete<?php echo e($data->id); ?>">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo e($data->pemilik); ?></h4>
            </div>
            <div class="modal-body">
                <p>Apakah anda yakin ingin menghapus data ini?</p>
            </div>
            <div class="modal-footer">
                <a href="" class="btn btn-outline pull-left" data-dismiss="modal">Tidak</a>
                <a href="/v_khusus/delete/<?php echo e($data->id); ?>" class="btn btn-outline">Ya</a>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_khusus/khusus.blade.php ENDPATH**/ ?>