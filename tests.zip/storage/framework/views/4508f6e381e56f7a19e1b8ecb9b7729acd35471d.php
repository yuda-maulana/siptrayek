
<?php $__env->startSection('title', 'Detail Izin Khusus'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <h4 class="box-title">Data Kendaraan</h4>
                    <a href="/v_khusus/edit/<?php echo e($khusus->id); ?>" class="btn btn-sm btn-warning pull-right">Edit Data</a>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>No. Urut</th>
                                <td><?php echo e($khusus->urut); ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal Terbit</th>
                                <td><?php echo e(Carbon\Carbon::parse($khusus->terbit)->isoFormat('D MMMM Y')); ?></td>
                            </tr>
                            <!-- <tr>
                                <th>Status</th>
                                <?php if(!(strtotime($khusus->tgl_sk) <= time() AND time()>= strtotime($khusus->akhir_sk))): ?>
                                    <td><span class="label label-success">Aktif</span></td>
                                    <?php else: ?>
                                    <td><span class="label label-danger">Tidak Aktif</span></td>
                                    <?php endif; ?>
                            </tr> -->
                            <tr>
                                <th>No. Uji / No. Kend / No. Bend</th>
                                <td><?php echo e($khusus->no_uji); ?> / <?php echo e($khusus->no_kend); ?> / <?php echo e($khusus->no_bend); ?></td>
                            </tr>
                            <tr>
                                <th>Nama Pemilik</th>
                                <td><?php echo e($khusus->pemilik); ?></td>
                            </tr>
                            <tr>
                                <th>Perusahaan</th>
                                <td><?php echo e($khusus->perusahaan); ?></td>
                            </tr>
                            <tr>
                                <th>Alamat</th>
                                <td><?php echo e($khusus->alamat); ?></td>
                            </tr>
                            <tr>
                                <th>Pimpinan</th>
                                <td><?php echo e($khusus->pimpinan); ?></td>
                            </tr>
                            <tr>
                                <th>No. Rangka / Mesin</th>
                                <td><?php echo e($khusus->rangka); ?> / <?php echo e($khusus->mesin); ?></td>
                            </tr>
                            <tr>
                                <th>Daya Angkut</th>
                                <td><?php echo e($khusus->dy_akt); ?> kg</td>
                            </tr>
                            <tr>
                                <th>Merk / Tahun</th>
                                <td><?php echo e($khusus->merk); ?> / <?php echo e($khusus->tahun); ?></td>
                            </tr>
                            <tr>
                                <th>Jenis Kendaraan</th>
                                <td><?php echo e($khusus->jenis); ?></td>
                            </tr>
                            <tr>
                                <th>Jenis Layanan</th>
                                <td><?php echo e($khusus->layanan); ?></td>
                            </tr>
                            <tr>
                                <th>Keperluan</th>
                                <td><?php echo e($khusus->keperluan); ?></td>
                            </tr>
                            <tr>
                                <th>Jenis Permohonan</th>
                                <td><?php echo e($khusus->catatan); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="box-footer">
                    <a href="../khusus" class="btn btn-success btn-sm ">Kembali</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <h4 class="box-title">Surat Keputusan dan Kartu Pengawasan</h4>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Nomor SK</th>
                                <td><?php echo e($khusus->no_sk); ?></td>
                                <th>Nomor KP</th>
                                <td><?php echo e($khusus->no_kp); ?></td>
                            </tr>
                            <tr>
                                <th>Berlaku SK</th>
                                <td><?php echo e(Carbon\Carbon::parse($khusus->tgl_sk)->isoFormat('D MMMM Y')); ?> s/d <?php echo e(Carbon\Carbon::parse($khusus->akhir_sk)->isoFormat('D MMMM Y')); ?></td>
                                <th>Berlaku KP</th>
                                <td><?php echo e(Carbon\Carbon::parse($khusus->tgl_kp)->isoFormat('D MMMM Y')); ?> s/d <?php echo e(Carbon\Carbon::parse($khusus->akhir_kp)->isoFormat('D MMMM Y')); ?></td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <h4 class="box-title">Uraian Biaya</h4>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Retribusi</th>
                                <td>Rp. <?php echo number_format($khusus->retri,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Denda Periode</th>
                                <td>Rp. <?php echo number_format($khusus->periode,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Denda Adm.</th>
                                <td>Rp. <?php echo number_format($khusus->administrasi,0,',','.'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_khusus/detail.blade.php ENDPATH**/ ?>