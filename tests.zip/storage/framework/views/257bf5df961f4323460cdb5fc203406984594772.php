
<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <a href="edit/<?php echo e(Auth::user()->id); ?>" class="btn btn-warning btn-sm">Edit Data</a>
                    <a href="editpassword" class="btn btn-primary btn-sm">Ubah Password</a>
                </div>
                <!-- /.box-header -->
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Nama</th>
                                <td><?php echo e(Auth::user()->name); ?></td>
                            </tr>
                            <tr>
                                <th>NIP</th>
                                <td><?php echo e(Auth::user()->nip); ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo e(Auth::user()->email); ?></td>
                            </tr>
                            <!-- <tr>
                                <th>Password</th>
                                <td><?php echo e(Auth::user()->password); ?></td>
                            </tr> -->
                            <tr>
                                <th>Foto</th>
                                <td>
                                    <?php if( Auth::user()->foto != ''): ?>
                                    <img src="<?php echo e(URL::to('/')); ?>/foto/<?php echo e(Auth::user()->foto); ?>" alt="" width="100px">
                                    <?php else: ?>
                                    <img src="<?php echo e(URL::to('/')); ?>/foto/no_image.jpg" alt="" width="100px">
                                    <?php endif; ?>
                                </td>

                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_profile/profile.blade.php ENDPATH**/ ?>