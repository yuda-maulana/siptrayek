<html>

<head>
    <link rel="icon" href="<?php echo e(asset('logo')); ?>/dishub.png" width="50px">
</head>

<body onload="window.print()">
    <div class="form-group">
        <h2 class="page-header" align="center">
            <h2 align="center">DAFTAR INSIDENTIL YANG DIPROSES</h2><br>
            <small class="pull-right"></small>
        </h2>
        <table border="1" cellspacing="1" cellpadding="1" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No Uji / Kend / Bend</th>
                    <th>Nama <br> Perusahaan <br> Alamat</th>
                    <th>Merk / Tahun / Habis Uji / Terbit</th>
                    <th>Maksud / Tujuan <br> Tanggal Perjalanan</th>
                </tr>
            </thead>

            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $insidentil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($no++); ?></td>
                    <td><?php echo e($data->no_uji); ?> / <?php echo e($data->no_kend); ?> / <?php echo e($data->no_bend); ?></td>
                    <td><?php echo e($data->pemilik); ?> <br> <?php echo e($data->perusahaan); ?> <br><?php echo e($data->alamat); ?></td>
                    <td><?php echo e($data->merk); ?> / <?php echo e($data->tahun); ?> <br><?php echo e(Carbon\Carbon::parse($data->habis_uji)->isoFormat('D MMMM Y')); ?> <br> <?php echo e(Carbon\Carbon::parse($data->terbit)->isoFormat('D MMMM Y')); ?></td>
                    <td align="justify"><?php echo e($data->maksud); ?> <br> <?php echo e($data->tujuan); ?> <br> <?php echo e(Carbon\Carbon::parse($data->tgl_awal_perjalanan)->isoFormat('D MMMM Y')); ?> s/d <?php echo e(Carbon\Carbon::parse($data->tgl_akhir_perjalanan)->isoFormat('D MMMM Y')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="7" align="center"><b>Jumlah Kendaraan : <?php echo e($no-1); ?> Unit/Kendaraan</b></td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_insidentil/cetaklaporan.blade.php ENDPATH**/ ?>