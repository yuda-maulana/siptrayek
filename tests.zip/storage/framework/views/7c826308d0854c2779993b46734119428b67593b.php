
<?php $__env->startSection('title', 'Detail Izin Insidentil'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                    <a href="/v_insidentil/edit/<?php echo e($insidentil->id); ?>" class="btn btn-sm btn-warning pull-right">Edit Data</a>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Tanggal</th>
                                <td><?php echo e(Carbon\Carbon::parse($insidentil->tanggal)->isoFormat('D MMMM Y')); ?></td>
                            </tr>
                            <tr>
                                <th>No. Urut</th>
                                <td><?php echo e($insidentil->urut); ?></td>
                            </tr>
                            <tr>
                                <th>No. Bend</th>
                                <td><?php echo e($insidentil->no_bend); ?></td>
                            </tr>
                            <tr>
                                <th>Pemilik</th>
                                <td><?php echo e($insidentil->pemilik); ?></td>
                            </tr>
                            <tr>
                                <th>Perusahaan</th>
                                <td><?php echo e($insidentil->perusahaan); ?></td>
                            </tr>
                            <tr>
                                <th>Alamat</th>
                                <td><?php echo e($insidentil->alamat); ?></td>
                            </tr>
                            <tr>
                                <th>No. Kend</th>
                                <td><?php echo e($insidentil->no_kend); ?></td>
                            </tr>
                            <tr>
                                <th>No. Uji</th>
                                <td><?php echo e($insidentil->no_uji); ?></td>
                            </tr>
                            <tr>
                                <th>Merk / Tahun</th>
                                <td><?php echo e($insidentil->merk); ?> / <?php echo e($insidentil->tahun); ?></td>
                            </tr>
                            <tr>
                                <th>Habis Uji</th>
                                <td><?php echo e(Carbon\Carbon::parse($insidentil->habis_uji)->isoFormat('D MMMM Y')); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="box-footer">
                    <a href="../insidentil" class="btn btn-success btn-sm ">Kembali</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box">
                <div class="box-header">
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Tanggal Perjalanan</th>
                                <td><?php echo e(Carbon\Carbon::parse($insidentil->tgl_awal_perjalanan)->isoFormat('D MMMM Y')); ?> s/d <?php echo e(Carbon\Carbon::parse($insidentil->tgl_akhir_perjalanan)->isoFormat('D MMMM Y')); ?></td>
                            </tr>
                            <tr>
                                <th>Tujuan</th>
                                <td><?php echo e($insidentil->tujuan); ?></td>
                            </tr>
                            <tr>
                                <th>Maksud</th>
                                <td><?php echo e($insidentil->maksud); ?></td>
                            </tr>
                            <tr>
                                <th>Retribusi</th>
                                <td>Rp. <?php echo number_format($insidentil->retri,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Leges</th>
                                <td>Rp. <?php echo number_format($insidentil->leges,0,',','.'); ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal Terbit</th>
                                <td><?php echo e(Carbon\Carbon::parse($insidentil->terbit)->isoFormat('D MMMM Y')); ?></td>
                            </tr>
                            <tr>
                                <th>Catatan</th>
                                <td><?php echo e($insidentil->catatan); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_insidentil/detail.blade.php ENDPATH**/ ?>