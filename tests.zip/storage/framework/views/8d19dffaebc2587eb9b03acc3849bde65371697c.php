<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <style>
        table.static {
            position: relative;

            border: 1px solid #543535;
        }
    </style>
    <title>Cetak Data</title>
</head>

<body>
    <div class="form-group">
        <h2 class="page-header" align="center">
            <i class="fa fa-globe"></i> Laporan Rekomendasi <br><br>
            <small class="pull-right">Tanggal : <?php echo e(date('d-M-Y')); ?></small>
        </h2>
        <table class="static" align="center" rules="all" border="1px" style="width: 95%;">
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>No. Bend</th>
                <th>Nama Pemilik</th>
                <th>Perusahaan / Alamat</th>
                <th>Jenis / Sifat Pelayanan</th>
                <th>Jenis / Jumlah Kendaraan</th>
                <!-- <th>Retribusi | Leges</th> -->
                <th>Trayek yang dimohon</th>
                <th>Tgl. Terbit</th>
                <th>Ket</th>
            </tr>
            <?php $no = 1; ?>
            <?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e(Carbon\Carbon::parse($data->tgl_rekom)->format('d/m/Y')); ?></td>
                <td><?php echo e($data->no_bend); ?></td>
                <td><?php echo e($data->pemilik); ?></td>
                <td><?php echo e($data->perusahaan); ?> / <?php echo e($data->alamat); ?></td>
                <td><?php echo e($data->jns_pelayanan); ?> / <?php echo e($data->sifat_pelayanan); ?></td>
                <td><?php echo e($data->jns_kendaraan); ?> / <?php echo e($data->jmlh_kendaraan); ?></td>
                <td><?php echo e($data->trayek_dimohon); ?></td>
                <td><?php echo e(Carbon\Carbon::parse($data->tgl_terbit)->format('d/m/Y')); ?></td>
                <td><?php echo e($data->keterangan); ?></td>
                <!-- <td><?php echo e($data->retribusi); ?> | <?php echo e($data->leges); ?></td> -->
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\project\dishub\resources\views/v_rekomendasi/printpdf.blade.php ENDPATH**/ ?>