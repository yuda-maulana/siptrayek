
<?php $__env->startSection('title', 'Ijin Insidentil'); ?>
<?php $__env->startSection('content'); ?>

<a href="add" class="btn btn-success btn-sm">Tambah Data</a><br><br>
<?php if(session('pesan')): ?>
<div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-check"></i> Berhasil!</h4>
    <?php echo e(session('pesan')); ?>

</div>
<?php endif; ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>No Uji/No. Kend/No. Bend</th>
            <th>Nama Pemilik</th>
            <th>Alamat</th>
            <th>Merk/Tahun</th>
            <th>Habis Uji - Terbit</th>
            <th>Maksud</th>
            <th>Tujuan</th>
            <th>Tanggal Perjalanan</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $no = 1; ?>
        <?php $__currentLoopData = $insidentil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($data->no_uji); ?>/<?php echo e($data->no_kend); ?>/<?php echo e($data->no_bend); ?></td>
            <td><?php echo e($data->nama_pemilik); ?></td>
            <td><?php echo e($data->alamat); ?></td>
            <td><?php echo e($data->merk); ?> / <?php echo e($data->tahun); ?></td>
            <td><?php echo e($data->habis_uji); ?> - <?php echo e($data->terbit); ?></td>
            <td><?php echo e($data->maksud); ?></td>
            <td><?php echo e($data->tujuan); ?></td>
            <td><?php echo e($data->tgl_awal_perjalanan); ?> s/d <?php echo e($data->tgl_akhir_perjalanan); ?> </td>
            <td> <a href="/v_insidentil/edit/<?php echo e($data->id_insidentil); ?>" class="btn btn-sm btn-warning">Edit</a>
                <br><br>
                <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete<?php echo e($data->id_insidentil); ?>">
                    Hapus
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__currentLoopData = $insidentil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal modal-danger fade" id="delete<?php echo e($data->id_insidentil); ?>">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo e($data->nama_pemilik); ?></h4>
            </div>
            <div class="modal-body">
                <p>Apakah anda yakin ingin menghapus data ini?</p>
            </div>
            <div class="modal-footer">
                <a href="" class="btn btn-outline pull-left" data-dismiss="modal">Tidak</a>
                <a href="/v_insidentil/delete/<?php echo e($data->id_insidentil); ?>" class="btn btn-outline">Ya</a>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dishub\resources\views/v_insidentil/insidentil.blade.php ENDPATH**/ ?>