 <html>

 <head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Laporan Lintasan Trayek</title>
     <link rel="icon" href="<?php echo e(asset('logo')); ?>/dishub.png" width="50px">

 </head>

 <body onload="window.print()">
     <div class="form-group">
         <h2 class="page-header" align="center">
             <i class="fa fa-globe"></i><u>LAPORAN LINTASAN TRAYEK</u><br><br>
             <small class="pull-right"></small>
         </h2>
         <table border="1" cellspacing="0" cellspadding="0" width="100%">
             <thead>
                 <tr>
                     <th>No</th>
                     <th>Kode Lintasan</th>
                     <th>Lintasan</th>
                     <th>Alokasi</th>
                     <th>Rute</th>
                 </tr>
             </thead>
             <tbody>
                 <?php $no = 1; ?>
                 <?php $__currentLoopData = $lintrayek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <td align="center"><?php echo e($no++); ?></td>
                     <td align="center"><?php echo e($data->kode); ?></td>
                     <td align="center"><?php echo e($data->lintasan); ?></td>
                     <td align="center"><?php echo e($data->alokasi); ?></td>
                     <td align="justify"><?php echo e($data->rute); ?></td>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
         </table>
     </div>
 </body>

 </html><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_lintrayek/printpdf.blade.php ENDPATH**/ ?>