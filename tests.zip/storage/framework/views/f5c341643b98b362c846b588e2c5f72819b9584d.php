
<?php $__env->startSection('title', 'Tambah Data Insidentil'); ?>
<?php $__env->startSection('content'); ?>

<form action="/perijinan/v_insidentil/insertinsidentil" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="content">
        <div class="row">
            <div class="col-sm-2">
                <div class="form-group">
                    <label>No. Uji</label>
                    <input type="text" name="no_uji" class="form-control" value="<?php echo e(old('no_uji')); ?>">
                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <label>No. Kend</label>
                    <input type="text" name="no_kend" class="form-control" value="<?php echo e(old('no_kend')); ?>">
                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <label>No. Bend</label>
                    <input type="text" name="no_bend" class="form-control" value="<?php echo e(old('no_bend')); ?>">

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Nama Pemilik</label>
                    <input type="text" name="nama_pemilik" class="form-control" value="<?php echo e(old('nama_pemilik')); ?>">

                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" name="alamat" class="form-control" value="<?php echo e(old('alamat')); ?>">

                </div>
                <div class="form-group">
                    <label>Merk</label>
                    <input type="text" name="merk" class="form-control" value="<?php echo e(old('merk')); ?>">

                </div>
                <div class="form-group">
                    <label>Tahun</label>
                    <input type="text" name="tahun" class="form-control" value="<?php echo e(old('tahun')); ?>">

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-2">
                <div class="form-group">
                    <label>Habis Uji</label>
                    <input type="date" name="habis_uji" class="form-control" value="<?php echo e(old('habis_uji')); ?>">

                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <label>Terbit</label>
                    <input type="date" name="terbit" class="form-control" value="<?php echo e(old('terbit')); ?>">

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Maksud</label>
                    <input type="text" name="maksud" class="form-control" value="<?php echo e(old('maksud')); ?>">

                </div>
                <div class="form-group">
                    <label>Tujuan</label>
                    <input type="text" name="tujuan" class="form-control" value="<?php echo e(old('tujuan')); ?>">

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-2">
                <div class="form-group">
                    <label>Tanggal Perjalanan</label>
                    <input type="date" name="tgl_awal_perjalanan" class="form-control" value="<?php echo e(old('tgl_awal_perjalanan')); ?>">

                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <label>Sampai</label>
                    <input type="date" name="tgl_akhir_perjalanan" class="form-control" value="<?php echo e(old('tgl_akhir_perjalana')); ?>">

                </div>
            </div>
        </div>
        <div class="form-group">
            <button class="btn btn-success btn-sm">Simpan</button>
            <a href="insidentil" class="btn btn-danger btn-sm">Batal</a>
        </div>


</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dishub\resources\views/perijinan/v_insidentil/addinsidentil.blade.php ENDPATH**/ ?>