
<?php $__env->startSection('title', 'Detail Lintasan Trayek'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-xs-15">
            <div class="box">
                <div class="box-header">
                    <a href="/v_trayek/edit/<?php echo e($trayek->id); ?>" class="btn btn-sm btn-warning pull-right">Edit Data</a>
                </div>
                <div class="box-body no-padding">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>No. Uji / No. Kend</th>
                                <td><?php echo e($trayek->no_uji); ?> / <?php echo e($trayek->no_kend); ?></td>
                            </tr>
                            <tr>
                                <th>Nama Pemilik</th>
                                <td><?php echo e($trayek->nama); ?></td>
                            </tr>
                            <tr>
                                <th>Perusahaan</th>
                                <td><?php echo e($trayek->perusahaan); ?></td>
                            </tr>
                            <tr>
                                <th>Alamat</th>
                                <td><?php echo e($trayek->alamat); ?></td>
                            </tr>
                            <tr>
                                <th>Pimpinan</th>
                                <td><?php echo e($trayek->pimpinan); ?></td>
                            </tr>
                            <tr>
                                <th>No. Rangka / Mesin</th>
                                <td><?php echo e($trayek->no_rangka); ?> / <?php echo e($trayek->mesin); ?></td>
                            </tr>
                            <tr>
                                <th>Seat / Barang</th>
                                <td><?php echo e($trayek->seat); ?> Orang / <?php echo e($trayek->barang); ?> kg</td>
                            </tr>
                            <tr>
                                <th>Merk / Tahun</th>
                                <td><?php echo e($trayek->merk); ?> / <?php echo e($trayek->tahun); ?></td>
                            </tr>
                            <tr>
                                <th>Lintasan Trayek</th>
                                <td><?php echo e($trayek->lintrayek->kode); ?> : <?php echo e($trayek->lintrayek->lintasan); ?></td>
                            </tr>
                            <tr>
                                <th>Jenis Kendaraan</th>
                                <td><?php echo e($trayek->jeniskend->jnskend); ?></td>
                            </tr>

                        </tbody>
                    </table>
                </div>
                <div class="box-footer">
                    <a href="../trayek" class="btn btn-success btn-sm ">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\dishub\resources\views/v_trayek/detail.blade.php ENDPATH**/ ?>