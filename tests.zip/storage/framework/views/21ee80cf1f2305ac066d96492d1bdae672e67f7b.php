
<?php $__env->startSection('title', 'Form Relisasi Izin Trayek'); ?>
<?php $__env->startSection('content'); ?>

<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box box-primary">
                <!-- <form role="form"> -->
                <div class="box-body">
                    <div class="row">
                        <form id="myform" name="myform" action="" method="post">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>
                                        <input type="radio" name="group1" value="lintasantertentu" checked="checked">
                                        Lintasan Tertentu
                                    </label>
                                    <br>
                                    <label>
                                        <input type="radio" name="group1" value="Perusahaan Tertentu">
                                        Perusahaan Tertentu
                                    </label>
                                    <br>
                                    <label>
                                        <input type="radio" name="group1" value="Pemilik Tertentu">
                                        Pemilik Tertentu
                                    </label>
                                    <br>
                                    <label>
                                        <input type="radio" name="group1" value="Seluruh Lintasan">
                                        Seluruh Lintasan
                                    </label>
                                    <br>
                                    <label>
                                        <input type="radio" name="group1" value="Angkutan Kota">
                                        Angkutan Kota
                                    </label>
                                    <br>
                                    <label>
                                        <input type="radio" name="group1" value="Angkutan Kota">
                                        Mobil Penumpang
                                    </label>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="lintrayek_id">Trayek</label>
                                    <select class="form-control" name="lintrayek_id" id="lintrayek_id">
                                        <option disabled value>Pilih Lintasan</option>
                                        <?php $__currentLoopData = $lintrayek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->kode); ?>:<?php echo e($item->lintasan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="pemilik">Pemilik</label>
                                    <input type="text" name="pemilik" class="form-control" id="pemilik" value="<?php echo e(old('pemilik')); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['pemilik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="perusahaan">Perusahaan</label>
                                    <input type="text" name="perusahaan" class="form-control" value="<?php echo e(old('perusahaan')); ?>" id="perusahaan">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="" onclick="this.href='/v_rekomendasi/cetaklaporan/'+ document.getElementById('tglawal').value + '/' + document.getElementById('tglakhir').value" target="_blank"><button class="btn btn-success">Cetak Laporan</button></a>
                    <a href="rekomendasi" class="btn btn-danger">Batal</a>
                </div>
                <!-- </form> -->
            </div>
        </div>
    </div>
</section>
<script>
    var form = document.forms['myform'];
    form.group1[0].onfocus = function() {
        form.lintrayek_id.disabled = false;
        form.pemilik.disabled = form.perusahaan.disabled = true;
    }
    form.group1[1].onfocus = function() {
        form.perusahaan.disabled = false;
        form.pemilik.disabled = form.lintrayek_id.disabled = true;
    }
    form.group1[2].onfocus = function() {
        form.pemilik.disabled = false;
        form.perusahaan.disabled = form.lintrayek_id.disabled = true;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_trayek/formrealisasi.blade.php ENDPATH**/ ?>