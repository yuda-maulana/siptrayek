
<?php $__env->startSection('title', 'User'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-6">
            <!-- general form elements -->
            <div class="box box-primary">
                <form role="form" action="" method="">
                    <div class="box-body">
                        <div class="form-group">
                            <label for="name">Nama</label>
                            <input type="text" name="name" class="form-control" id="name" value="<?php echo e($user->name); ?>">
                        </div>
                        <div class="form-group">
                            <label for="nip">NIP</label>
                            <input type="text" name="nip" class="form-control" id="nip" value="<?php echo e($user->nip); ?>">
                        </div>
                        <div class="form-group">
                            <label for="name">Email</label>
                            <input type="text" name="email" class="form-control" id="email" value="<?php echo e($user->email); ?>">
                        </div>
                        <div class="form-group">
                            <label for="foto">File input</label>
                            <input type="file" name="foto" id="foto" value="<?php echo e($user->foto); ?>">
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\dishub\resources\views/v_user/edit.blade.php ENDPATH**/ ?>