<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Izin Trayek | Laporan Penerimaan Biaya Izin Trayek</title>
    <link rel="icon" href="<?php echo e(asset('logo')); ?>/dishub.png" width="50px">
</head>

<body onload="window.print()">
    <div class="form-group">
        <h2 class="page-header" align="center">
            <h2 align="center"><u>REKAPITULASI PENERIMAAN BIAYA TRAYEK</u></h2><br>
            <small class="pull-right"></small>
        </h2>
        <table border="1" cellspacing="1" cellpadding="1" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No. Uji <br> No. Kend</th>
                    <th>Pemilik <br> Perusahaan <br> Alamat</th>
                    <th>Jenis, Merk, Tahun Kendaraan</th>
                    <th>Seat</th>
                    <th>Retribusi SK</th>
                    <th>Retribusi KP</th>
                    <th>Jumlah Retribusi</th>
                    <th>Denda Periode</th>
                    <th>Denda Administrasi</th>
                    <th>Jumlah</th>
                    <th>Keterangan <br>Kode dan Lintasan Trayek</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $trayek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($no++); ?></td>
                    <td><?php echo e($data->no_uji); ?> <br><?php echo e($data->no_kend); ?></td>
                    <td><?php echo e($data->pemilik); ?> <br> <?php echo e($data->perusahaan); ?> <br><?php echo e($data->alamat); ?></td>
                    <td><?php echo e($data->jenis); ?> <br><?php echo e($data->merk); ?> <br><?php echo e($data->tahun); ?></td>
                    <td><?php echo e($data->orang); ?></td>
                    <td>Rp. <?php echo number_format($data->ret_sk,0,',','.'); ?></td>
                    <td>Rp. <?php echo number_format($data->ret_kp,0,',','.'); ?></td>
                    <td>Rp. <?php echo number_format($data->ret_sk+$data->ret_kp,0,',','.'); ?></td>
                    <td>Rp. <?php echo number_format($data->denda_periode,0,',','.'); ?> </td>
                    <td>Rp. <?php echo number_format($data->denda_admin,0,',','.'); ?></td>
                    <td>Rp. <?php echo number_format($data->ret_sk+$data->ret_kp+$data->denda_periode+$data->denda_admin,0,',','.'); ?></td>
                    <td><?php echo e($data->catatan); ?> <br><?php echo e($data->lintrayek->kode); ?> / <?php echo e($data->lintrayek->lintasan); ?> </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="5" align="center"><b>Jumlah Total</b></td>
                    <td><b>Rp. <?php echo number_format($trayek->sum('ret_sk'),0,',','.'); ?></b></td>
                    <td><b>Rp. <?php echo number_format($trayek->sum('ret_kp'),0,',','.'); ?></b></td>
                    <td><b>Rp. <?php echo number_format($trayek->sum('ret_sk')+$trayek->sum('ret_kp'),0,',','.'); ?></b></td>
                    <td><b>Rp. <?php echo number_format($trayek->sum('denda_periode'),0,',','.'); ?></b></td>
                    <td><b>Rp. <?php echo number_format($trayek->sum('denda_admin'),0,',','.'); ?></b></td>
                    <td><b>Rp. <?php echo number_format($trayek->sum('ret_sk')+$trayek->sum('ret_kp')+$trayek->sum('denda_periode')+$trayek->sum('denda_admin'),0,',','.'); ?></b></td>
                    <td><b>Jumlah Kendaraan : <?php echo e($no-1); ?> Unit/Kendaraan</b></td>
                </tr>
            </tbody>
        </table>
        <table border="0" align="left">
            <tr>
                <td></td>
            </tr>
            <tr>
                <td align="center">Mengetahui</td>
            </tr>
            <tr>
                <td colspan="3" align="center">
                    <font size=2>
                        KEPALA BIDANG ANGKUTAN<br>
                </td>
            </tr>
            <tr>
                <td height=70></td>
            </tr>
            <tr>
                <td colspan="3" align="center"><b><u>Ajat Sudrajat, ATD, MM</u></b></td>
            </tr>
            <tr>
                <td colspan="3" align="center">NIP. 196907051994031021</td>
            </tr>
        </table>
        <table border="0" align="right">
            <tr>
                <td align="center">Tasimalaya</td>
            </tr>
            <tr>
                <td colspan="3" align="center">
                    <font size=2>
                        KEPALA SEKSI BINA USAHA ANGKUTAN<br>
                </td>
            </tr>
            <tr>
                <td height=70></td>
            </tr>
            <tr>
                <td colspan="3" align="center"><b><u>Denny Iskandar, A.Md</u></b></td>
            </tr>
            <tr>
                <td colspan="3" align="center">NIP. 196702121990021000</td>
            </tr>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\kerjapraktek\project\dishub\resources\views/v_trayek/cetakpenerimaan.blade.php ENDPATH**/ ?>